using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyTitle("Thorlabs.ccs.interop64")]
[assembly: AssemblyDescription("DotNET Wrapper for VXIpnp Instrument Driver 64Bit")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Thorlabs GmbH")]
[assembly: AssemblyProduct("Thorlabs CCS")]
[assembly: AssemblyCopyright("Copyright © Thorlabs 2013")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("88e868b0-ee79-4e7c-8bec-f114ea1f0acd")]
[assembly: AssemblyFileVersion("2.0.0.0")]
[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: AssemblyVersion("2.0.0.0")]
